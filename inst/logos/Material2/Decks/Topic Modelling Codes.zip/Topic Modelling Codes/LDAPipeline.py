
# coding: utf-8
#### Implementing LDA using gensim adn calculate Coherence Scores
# In[1]:


import warnings
warnings.filterwarnings("ignore",category=DeprecationWarning)
warnings.filterwarnings("ignore",category=RuntimeWarning)


# In[2]:


import pandas as pd
data_total = pd.read_csv(r"PerceptionSpamRemoved.csv", encoding = 'latin-1', engine = 'python', error_bad_lines=False)
len(data_total)


# In[3]:


df = data_total[:10000]


# In[4]:


from nltk.util import ngrams
from collections import Counter
df['Contents'] = df['Contents'].str.replace('[^a-zA-Z\s@#$]','')
df['Contents'] = df['Contents'].apply(lambda x: [x for x in str(x).lower().split()])
df['Contents'] = df['Contents'].apply(lambda x: ngrams(x,2))
df['Contents'] = df['Contents'].apply(lambda x: [' '.join(item) for item in list(x)])


# In[5]:


df.Contents.iloc[4]


# In[6]:


# Gensim
import gensim
import gensim.corpora as corpora
from gensim.utils import simple_preprocess
from gensim.models import CoherenceModel


# In[7]:


# Plotting tools
import pyLDAvis
import pyLDAvis.gensim  # don't skip this
import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')


# In[8]:


# Create Dictionary
id2word = corpora.Dictionary(df.Contents.tolist())

# Create Corpus
texts = df.Contents.tolist()

# Term Document Frequency
corpus = [id2word.doc2bow(text) for text in texts]

# View
print(corpus[:1])


# In[12]:


# Build LDA model
lda_model = gensim.models.ldamodel.LdaModel(corpus=corpus,
                                           id2word=id2word,
                                           num_topics=10, 
                                           random_state=100,
                                           update_every=1,
                                           chunksize=100,
                                           passes=10,
                                           alpha='auto',
                                           per_word_topics=True)


# In[13]:


print(lda_model.print_topics())
doc_lda = lda_model[corpus]


# In[14]:


# Compute Coherence Score
coherence_model_lda = CoherenceModel(model=lda_model, texts=df.Contents.tolist(), dictionary=id2word, coherence='c_v')
coherence_lda = coherence_model_lda.get_coherence()
print('\nCoherence Score: ', coherence_lda)


# In[15]:


pyLDAvis.enable_notebook()
vis = pyLDAvis.gensim.prepare(lda_model, corpus, id2word)
vis


# In[17]:


import zipfile
zip_ref = zipfile.ZipFile("mallet-2.0.8.zip", 'r')
zip_ref.extractall()
zip_ref.close()


# In[43]:


# Download File: http://mallet.cs.umass.edu/dist/mallet-2.0.8.zip
mallet_path = r'mallet-2.0.8\\bin\\mallet' # update this path
ldamallet = gensim.models.wrappers.LdaMallet(mallet_path, corpus=corpus, num_topics=5, id2word=id2word)

