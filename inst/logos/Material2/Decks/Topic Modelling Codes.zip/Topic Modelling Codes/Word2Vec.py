# -*- coding: utf-8 -*-
"""
Created on Mon Sep 10 10:16:08 2018

@author: yoshitha.akunuri
"""
#### Word2Vec Sample and KMeans clustering

import pandas as pd

# Read the data into a data frame

data = pd.read_csv(r'D:\ASI - BRT\Tagging\BlackrockDataTestSample.csv', encoding='latin-1')
data = data.loc[data['Language'] == "English"]

# BASIC PREPROCESSING

# Remove digits

data['Contents'] = data['Contents'].apply(lambda x: ''.join([i for i in str(x) if not i.isdigit()]))
# Lower Case

data['Contents'] = data['Contents'].apply(lambda x: " ".join(x.lower() for x in str(x).split()))
data['Contents'].head()

#Remove URL's

data['Contents'] = data['Contents'].apply(lambda x: " ".join(x for x in str(x).split() if x.startswith("http") == False))
data['Contents'].head()


#Remove Punctuations

data['Contents'] = data['Contents'].str.replace('[^\w\s@]','')
data['Contents'].head()

# Stopwords Removal

from nltk.corpus import stopwords
stop = stopwords.words('english')
data['Contents'] = data['Contents'].apply(lambda x: " ".join(x for x in x.split() if x not in stop))
data['Contents'].head()

# Rare words Removal - optional 
Rare = pd.Series(' '.join(data['Contents']).split()).value_counts()
Rare = Rare[Rare <= 15]
data['Contents'] = data['Contents'].apply(lambda x: " ".join(x for x in x.split() if x not in Rare))
data['Contents'].head()

# Spelling Correction
from textblob import TextBlob
data['Contents'].apply(lambda x: str(TextBlob(x).correct()))

#Lemmatisation

from textblob import Word
data['Contents'] = data['Contents'].apply(lambda x: " ".join([Word(word).lemmatize() for word in x.split()]))
data['Contents'].head()

# BAG OF WORDS

# Removing rt and qt
data['Contents'] = data['Contents'].apply(lambda x: " ".join(x for x in x.split() if x not in ["rt", "qt"]))

#Sampling data
training_data = data[0:1000]

# Bag of words 

from sklearn.feature_extraction.text import CountVectorizer

vectorizer = CountVectorizer(analyzer = "word", tokenizer = None, preprocessor = None, stop_words = None)
train_data_features = vectorizer.fit_transform(training_data['Contents'])
print (train_data_features.shape)
vocab = vectorizer.get_feature_names()
print (vocab)

df = pd.DataFrame(train_data_features.toarray())
df.columns = vocab
df.index = data[0:1000]["Contents"]

import numpy as np

# Sum up the counts of each vocabulary word
dist = np.sum(train_data_features, axis=0)

# For each, print the vocabulary word and the number of times it 
# appears in the training set
CountBagOfWords = {}
for i in range(len(vocab)):
    CountBagOfWords[vocab[i]] = dist[0, i]
    
    
from gensim.models import KeyedVectors
# load the google word2vec model
filename = r'C:\Users\yoshitha.akunuri\Downloads\GoogleNews-vectors-negative300.bin'
model = KeyedVectors.load_word2vec_format(filename, binary=True)
# calculate: (king - man) + woman = ?
result = model.most_similar(positive=['woman', 'king'], negative=['man'], topn=1)
print(result)






from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
from sklearn.metrics import adjusted_rand_score


documents = ["This little kitty came to play when I was eating at a restaurant.",
             "Merley has the best squooshy kitten belly.",
             "Google Translate app is incredible.",
             "If you open 100 tab in google you get a smiley face.",
             "Best cat photo I've ever taken.",
             "Climbing ninja cat.",
             "Impressed with google map feedback.",
             "Key promoter extension for Google Chrome."]

vectorizer = TfidfVectorizer(stop_words='english')
X = vectorizer.fit_transform(documents)

true_k = 3
model = KMeans(n_clusters=true_k, init='k-means++', max_iter=100, n_init=1)
model.fit(X)
print("Top terms per cluster:")
order_centroids = model.cluster_centers_.argsort()[:, ::-1]
terms = vectorizer.get_feature_names()


for i in range(true_k):
    print("Cluster %d:" % i),
    for ind in order_centroids[i, :10]:
        print(' %s' % terms[ind]),
    print
    
Y = vectorizer.transform(["chrome browser to open."])
prediction = model.predict(Y)
print(prediction)

Y = vectorizer.transform(["My cat is hungry."])
prediction = model.predict(Y)
print(prediction)

from sklearn.feature_extraction.text import TfidfVectorizer

from sklearn.cluster import KMeans
Optimal_k = 4

WordVectorizer = TfidfVectorizer(stop_words='english')

X = WordVectorizer.fit_transform(training_data['Contents'])

model = KMeans(n_clusters=Optimal_k, init='k-means++', max_iter=200, n_init=10)

model.fit(X)
order_centroids = model.cluster_centers_.argsort()[:, ::-1]
training_data['Cluster'] = pd.DataFrame(model.labels_)

terms = WordVectorizer.get_feature_names()

for i in range(Optimal_k):
    print("Cluster %d:" % i),
    for ind in order_centroids[i, :10]:
        print(' %s' % terms[ind]),
    print
    break
